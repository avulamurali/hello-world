package com.murali.foodtruck.api;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.murali.foodtruck.custom_exception.AddressNotFoundException;
import com.murali.foodtruck.dto.Location;
import com.murali.foodtruck.dto.Truck;
import com.murali.foodtruck.dto.TruckList;
import com.murali.foodtruck.services.TruckService;

/**
 * @author murali
 * 
 */

public class TruckController {

	private TruckService truckService;
	private double ftLat = 37.7653706693171;// 37.7801490737255;
	private double ftLng = -122.419000119489; // -122.422258184604;

	public TruckController() {
	}

	public String welcome(String address) {
		List<Truck> truckList = new ArrayList<Truck>();
		Location addressLoc = new Location(false, this.ftLng, this.ftLat);
		
		truckService=new TruckService();
		try {
			if (address != null) {
				System.out.println("---");
				truckList = truckService.getTrucks(address);
				JSONObject latLng = truckService.getLatLng(address);
				addressLoc.setLatitude(latLng.has("lat") ? latLng
						.getDouble("lat") : 0);
				addressLoc.setLongitude(latLng.has("lng") ? latLng
						.getDouble("lng") : 0);
				
			}
		} catch (JSONException e) {
			System.out.println(e.getMessage());
		} catch (ClientProtocolException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (URISyntaxException e) {
			System.out.println(e.getMessage());
		} catch (AddressNotFoundException e) {
			System.out.println(e.getMessage());

		}
		System.out.println("---list--" + truckList.size());
		TruckList truckList2=new TruckList();
		truckList2.setLocation(addressLoc);
		truckList2.setTrucks(truckList);
		System.out.println("***truck details ***");
		System.out.println("********************************");
		System.out.println("***location of address Longitude and latitude "+truckList2.getLocation().getLongitude()+"***"+truckList2.getLocation().getLatitude());
		System.out.println("********************************");
		if(truckList2.getTrucks()!=null&&truckList2.getTrucks().size()>0){
			for (Truck truck : truckList) {
				System.out.println("***near by trucks List*****"+truck.getApplicant()+"***"+truck.getFooditems());	
			}
		}
		System.out.println("***near by trucks List***");
		/**  for controller
		* model.addAttribute("truckList", truckList);
		* model.addAttribute("address", addressLoc);

		* return truckList2;
		* return truckList2 dto for rest api
		**/
		return "success";
	}

	public static void main(String[] args) {
		TruckController controller = new TruckController();
		
		// enter the address here ... you can see list of trucks near by printed in log or in truckList2 dto
		controller.welcome("1104 FITZGERALD AVE");
		//controller.welcome("150 RUSS ST");

	}
	// we can use spring to  make this class as controller which returns model view OR we can  make this class as rest API and expose service to call from UI
}
