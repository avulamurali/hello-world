package com.murali.foodtruck.dto;

import java.io.Serializable;
import java.util.List;

public class TruckList implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1010220141088443742L;

	private List<Truck> trucks;

	private Location location;



	public List<Truck> getTrucks() {
		return trucks;
	}

	public void setTrucks(List<Truck> trucks) {
		this.trucks = trucks;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}
	
	
}
