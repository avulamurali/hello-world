/**
 * 
 */
package com.murali.foodtruck.tests;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.codehaus.jettison.json.JSONException;
import org.junit.Assert;
import org.junit.Test;

import com.murali.foodtruck.custom_exception.AddressNotFoundException;
import com.murali.foodtruck.dto.Truck;
import com.murali.foodtruck.services.TruckService;

/**
 * @author murali
 *
 */



public class TruckServiceTest {
	
	private TruckService truckService;
	
	
	public TruckServiceTest() {
		truckService=new TruckService();
	}
	
	@Test
	public void testGetNoTrucks() {
		List<Truck> trucks = null;
		try {
			trucks = truckService.getTrucks("3330 Cabrillo Ave, Santa Clara, Ca");
		} catch (JSONException e) {
			System.out.println(e.getMessage());
		} catch (ClientProtocolException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (URISyntaxException e) {
			System.out.println(e.getMessage());
		} catch (AddressNotFoundException e) {
			System.out.println(e.getMessage());
		}
		Assert.assertTrue(trucks.isEmpty());
	}
	
	@Test
	public void testGetSomeTrucks() {
		List<Truck> trucks = null;
		try {
			trucks = truckService.getTrucks("Geary blvd and Divisadero st, sf, ca");
		} catch (JSONException e) {
			System.out.println(e.getMessage());
		} catch (ClientProtocolException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (URISyntaxException e) {
			System.out.println(e.getMessage());
		} catch (AddressNotFoundException e) {
			System.out.println(e.getMessage());
		}
		Assert.assertTrue(trucks.size()==1);
	}
	
	@Test
	public void testInvalidAddress() {
		List<Truck> trucks = null;
		try {
			trucks = truckService.getTrucks("Foobar baz whazzzza");
		} catch (JSONException e) {
			System.out.println(e.getMessage());
		} catch (ClientProtocolException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (URISyntaxException e) {
			System.out.println(e.getMessage());
		} catch (AddressNotFoundException e) {
			System.out.println(e.getMessage());
			Assert.assertSame("Sorry, the address is not found.", e.getMessage());
		}
	}

	public static void main(String[] args) {
	}

}
