package com.murali.foodtruck.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({
        TruckControllerTest.class, //test case 1
        TruckServiceTest.class
})

public class JunitTests {

}
