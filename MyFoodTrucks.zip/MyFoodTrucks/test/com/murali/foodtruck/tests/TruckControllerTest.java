package com.murali.foodtruck.tests;




import org.junit.Assert;
import org.junit.Test;

import com.murali.foodtruck.api.TruckController;




public class TruckControllerTest

{
	private TruckController truckController;

	
	
	public TruckControllerTest() {
		super();
		truckController=new TruckController();
	}



	@Test
	public void testValidAddress() {
	
		String view = truckController.welcome("1104 FITZGERALD AVE");
		Assert.assertTrue(view.equalsIgnoreCase("success"));
	}
}
